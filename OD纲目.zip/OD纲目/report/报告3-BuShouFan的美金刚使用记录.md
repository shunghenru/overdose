# 报告3-BuShouFan的美金刚使用记录
处理报告者:shunghenru  
![shunghenru](../图片报告用/工作人员-wiki成员/shunghenru.jpg)
报告时：2025.03.23  
写入时：2025.03.23  
报告人:BuShouFan    
![BuShouFan](../图片报告用/试药人员-报告人员/BuShouFan.png)
有关药物:<span style="background: linear-gradient(to right, red, yellow, green, blue); -webkit-background-clip: text; color: transparent;">美金刚200mg</span>
时间15:51 解离,有明显眩晕症状,无明显外部幻觉。
对话如下。
- B:o了120mg
- B:看看吧
- A:要帮你记下来吗
- B:大概不会有什么效果（）,先看看吧
- B:17:00   150mg美金刚
- A:还活着吗
- B:活着呢,这点剂量没啥,再补50mg吧（
- A:666
- B:如果再补50mg我就只剩2t了,那不如直接全o了,
- A:你究竟吃了多少（
- B:200mg,留了10mg不吃了
- B:解离了[表情包]
- B:幻觉应该是没有的,不过是挺晕的,不好吃
- 记录终止